
plugins {
    id("com.gtnewhorizons.gtnhconvention")
}
